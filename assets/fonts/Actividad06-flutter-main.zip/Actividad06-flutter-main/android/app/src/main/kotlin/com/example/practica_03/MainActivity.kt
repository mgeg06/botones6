package com.example.practica_03

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
