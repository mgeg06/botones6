//import 'dart:js_util';
import 'package:practica_03/src/app.dart';

import 'package:flutter/material.dart';


void main() {
  runApp(MaterialApp(
    home: MyApp(),
  ));
}
